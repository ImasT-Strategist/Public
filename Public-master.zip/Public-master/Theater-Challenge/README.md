# Public
ミリシタTCのログ分析（統制のとれた陣営はどこだ？）
※ [matsurihi.me](https://twitter.com/matsurihi_me)さんが収集したデータをもとに分析しています。